import SwiftUI
import Combine
import UIKit

struct ContentView: View {
    @StateObject private var appState = AppState()

    var body: some View {
        Group {
            switch appState.currentScreen {
            case .eventForm:
                EventFormView(appState: appState)
            case .decisionReveal:
                DecisionRevealView(appState: appState)
            case .mainApp:
                MainAppView(appState: appState)
            }
        }
        .alert("Notice", isPresented: Binding(
            get: { appState.errorMessage != nil },
            set: { _ in appState.errorMessage = nil }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(appState.errorMessage ?? "Unknown error")
        }
    }
}

@MainActor
final class AppState: ObservableObject {
    @Published var currentScreen: AppScreen = .eventForm
    // The backend is the sole source of truth for what events exist —
    // populated exclusively by LivePositionsModel's SSE stream. Nothing
    // in this class appends, mutates, or removes entries directly.
    @Published var activeEvents: [ActiveEvent] = []
    @Published var latestDecision: RouteEventResponse?
    @Published var isSubmitting = false
    @Published var errorMessage: String?
    // Hoisted out of MainAppView so re-entering .mainApp doesn't reset
    // the user back to the first tab — MainAppView gets torn down and
    // rebuilt every time currentScreen swaps away and back, so any
    // @State living inside it wouldn't survive that round trip. This
    // does, because it lives here.
    @Published var selectedMainTab = 0

    private let apiService: APIService
    let livePositionsModel: LivePositionsModel

    init(apiService: APIService = APIService()) {
        self.apiService = apiService
        self.livePositionsModel = LivePositionsModel(apiService: apiService)

        // Wired as a callback (rather than AppState reaching into
        // livePositionsModel.activeEvents itself) so activeEvents stays a
        // real @Published property ON AppState. A computed property that
        // merely forwarded to livePositionsModel.activeEvents would NOT
        // trigger AppState's own objectWillChange when the stream
        // updates it — views observing `@ObservedObject var appState`
        // (most of them) simply wouldn't refresh. This way every push
        // republishes through AppState itself, so every existing call
        // site (appState.activeEvents) stays live-updated.
        self.livePositionsModel.onEventsReceived = { [weak self] events in
            self?.activeEvents = events
        }
    }

    func submitEvent(room: String, symptomTags: [String], submittedAt: String) {
        isSubmitting = true
        errorMessage = nil

        Task {
            do {
                let response = try await apiService.routeEvent(room: room, symptomTags: symptomTags, submittedAt: submittedAt)
                // latestDecision comes straight from this response — fine
                // and correct, it's immediate feedback for the screen the
                // user is looking at right now. activeEvents is NOT
                // hand-appended from it: the backend signals its own
                // change the moment this write lands (see store.py's
                // _signal_change), and the already-open SSE stream pushes
                // the update on its own — no manual refresh needed here.
                latestDecision = response
                currentScreen = .decisionReveal
            } catch {
                errorMessage = error.localizedDescription
            }
            isSubmitting = false
        }
    }

    func continueToMainApp() {
        currentScreen = .mainApp
    }

    /// The "go back to submit" entry point, called from a persistent
    /// button in MainAppView. Purely a navigation action — activeEvents,
    /// latestDecision, and the live stream all keep running via appState
    /// regardless of which screen is showing.
    func reportAnotherEvent() {
        errorMessage = nil
        currentScreen = .eventForm
    }

    func clearAssignment(for staff: StaffPosition) {
        guard let event = activeEvents.first(where: { $0.assignedStaffId == staff.staff_id && $0.status != "resolved" }) else {
            return
        }

        Task {
            do {
                _ = try await apiService.clearAssignment(eventId: event.id)
                // Same principle: don't hand-patch activeEvents from this
                // response. The write's own _signal_change() on the
                // backend means the stream pushes the true resulting
                // state (including any reassigned_pending event) on its
                // own, typically before this call even returns.
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}

/// Owns the live connection to the backend's simulation state — staff
/// positions AND events both, from one SSE stream (/dashboard-stream),
/// rather than a Timer polling for either. The backend pushes a full
/// snapshot the instant anything changes (an explicit write, or a
/// time-based transition it discovers on its own ~1s tick); this class
/// just applies whatever it's sent. No local mutation, no bookkeeping —
/// see AppState.onEventsReceived wiring above for why that matters.
@MainActor
final class LivePositionsModel: ObservableObject {
    @Published var staffPositions: [StaffPosition] = []
    // True whenever the stream isn't currently connected (initial
    // connect, or a reconnect in progress after a drop).
    @Published var isLoading = true
    @Published var errorMessage: String?

    var onEventsReceived: (([ActiveEvent]) -> Void)?

    private let apiService: APIService
    private var streamTask: Task<Void, Never>?
    private var lifecycleObserver: NSObjectProtocol?
    private let reconnectDelaySeconds: UInt64 = 2

    init(apiService: APIService) {
        self.apiService = apiService
        startStreaming()
        observeAppLifecycle()
    }

    deinit {
        streamTask?.cancel()
        if let lifecycleObserver {
            NotificationCenter.default.removeObserver(lifecycleObserver)
        }
    }

    func startStreaming() {
        streamTask?.cancel()
        streamTask = Task { [weak self] in
            await self?.streamLoop()
        }
    }

    /// One-off fallback fetch. Not needed for normal operation — the
    /// stream pushes a full snapshot the instant it connects, and again
    /// the instant anything changes server-side — but kept as an escape
    /// hatch (e.g. a manual pull-to-refresh gesture, if one gets added).
    func refreshNow() async {
        do {
            let state = try await apiService.fetchDashboardState()
            apply(state)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func streamLoop() async {
        while !Task.isCancelled {
            do {
                try await connectAndConsume()
            } catch {
                if Task.isCancelled { return }
                isLoading = true
                errorMessage = humanReadable(error)
            }
            if Task.isCancelled { return }
            try? await Task.sleep(nanoseconds: reconnectDelaySeconds * 1_000_000_000)
        }
    }

    private func connectAndConsume() async throws {
        let (bytes, response) = try await apiService.openDashboardStream()
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }

        isLoading = false
        errorMessage = nil

        var dataBuffer = ""
        for try await line in bytes.lines {
            if Task.isCancelled { return }

            if line.isEmpty {
                // Blank line = SSE event boundary; dispatch what we've
                // accumulated for this event.
                if !dataBuffer.isEmpty {
                    apply(payload: dataBuffer)
                    dataBuffer = ""
                }
                continue
            }
            if line.hasPrefix(":") { continue } // SSE comment/keep-alive
            if line.hasPrefix("data:") {
                let value = String(line.dropFirst(5)).trimmingCharacters(in: .whitespaces)
                dataBuffer += value
            }
        }

        // The for-await loop only exits when the server closes the
        // connection — treat that the same as any other disconnect, so
        // the outer streamLoop backs off and reconnects.
        isLoading = true
        throw URLError(.networkConnectionLost)
    }

    private func apply(payload: String) {
        guard let data = payload.data(using: .utf8) else { return }
        do {
            let state = try JSONDecoder().decode(DashboardStateResponse.self, from: data)
            apply(state)
        } catch {
            errorMessage = "Failed to decode live update: \(error.localizedDescription)"
        }
    }

    private func apply(_ state: DashboardStateResponse) {
        staffPositions = state.staff
        onEventsReceived?(state.events.map(ActiveEvent.init(from:)))
    }

    private func humanReadable(_ error: Error) -> String {
        if let urlError = error as? URLError, urlError.code == .networkConnectionLost {
            return "Live connection dropped — reconnecting…"
        }
        return error.localizedDescription
    }

    /// SSE connections don't survive iOS suspending the app in the
    /// background — the socket gets torn down while backgrounded.
    /// Restart the stream as soon as the app becomes active again,
    /// rather than waiting out the normal reconnect backoff.
    private func observeAppLifecycle() {
        lifecycleObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.startStreaming()
        }
    }
}

#Preview {
    ContentView()
}
