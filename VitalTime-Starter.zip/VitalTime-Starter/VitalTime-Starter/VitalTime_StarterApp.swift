//
//  VitalTime_StarterApp.swift
//  VitalTime-Starter
//
//  Created by Anirudh Srivastava on 7/6/26.
//

import SwiftUI

@main
struct VitalTime_StarterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
