import SwiftUI

struct FacilityMapView: View {
    @ObservedObject var livePositionsModel: LivePositionsModel
    @ObservedObject var appState: AppState

    var body: some View {
        NavigationStack {
            List {
                Section("Active events") {
                    if appState.activeEvents.isEmpty {
                        Text("No active events yet.")
                            .foregroundStyle(.secondary)
                            .font(.subheadline)
                    } else {
                        ForEach(appState.activeEvents) { event in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Circle()
                                        .fill(Color.tierColor(for: event.tier))
                                        .frame(width: 12, height: 12)
                                    Text("Room \(event.room)")
                                        .font(.headline)
                                    Spacer()
                                    Text(event.status)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Text("Assigned: \(event.assignedStaffId ?? "pending")")
                                    .font(.subheadline)
                                Text("Tier \(event.tier) • \(event.symptomTags.joined(separator: ", "))")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }

                Section("Staff positions") {
                    if livePositionsModel.isLoading && livePositionsModel.staffPositions.isEmpty {
                        HStack {
                            ProgressView()
                            Text("Loading staff…")
                                .foregroundStyle(.secondary)
                        }
                    } else if livePositionsModel.staffPositions.isEmpty {
                        Text("No staff data available.")
                            .foregroundStyle(.secondary)
                            .font(.subheadline)
                    } else {
                        ForEach(livePositionsModel.staffPositions) { staff in
                            HStack {
                                Circle()
                                    .fill(staff.status == "busy" ? Color.red.opacity(0.8) : Color.green.opacity(0.8))
                                    .frame(width: 12, height: 12)
                                VStack(alignment: .leading) {
                                    Text(staff.staff_id)
                                        .font(.subheadline.bold())
                                    Text("\(staff.role) • \(staff.current_position.room)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Button("Clear") {
                                    appState.clearAssignment(for: staff)
                                }
                                .buttonStyle(.bordered)
                                .disabled(staff.status != "busy")
                            }
                        }
                    }
                }
            }
            .navigationTitle("Facility map")
        }
    }
}
