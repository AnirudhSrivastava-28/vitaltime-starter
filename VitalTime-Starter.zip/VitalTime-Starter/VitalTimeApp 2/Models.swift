import Foundation
import SwiftUI

struct RouteEventResponse: Codable, Equatable {
    let event_id: String
    let tier: Int
    let assigned_staff_id: String?
    let eta: Double?
    let fatigue_score_at_assignment: Double?
    let status: String
}

struct StaffPositionResponse: Codable, Equatable {
    let room: String
}

struct StaffPosition: Codable, Identifiable, Equatable {
    let staff_id: String
    let role: String
    let qualification_level: String
    let shift_start: String
    let current_position: StaffPositionResponse
    let status: String
    let current_event_id: String?
    let hours_in_shift: Double
    let fatigue_score: Double

    var id: String { staff_id }
}

struct ClearAssignmentResponse: Codable, Equatable {
    let event_id: String
    let status: String
    let reassigned_pending: RouteEventResponse?
}

struct ResetSimulationResponse: Codable, Equatable {
    let status: String
}

/// Decodes GET /events and the `events` array inside GET /dashboard-state.
/// Mirrors backend/app/routers/routing.py's EventItem exactly, including
/// eta/fatigue_score_at_assignment — those are now persisted on the Event
/// itself server-side (not just returned once by /route-event), so a
/// fresh poll always has them, not only whatever the app cached from the
/// response it happened to receive at submission time.
struct EventItem: Codable, Identifiable, Equatable {
    let event_id: String
    let room: String
    let tier: Int
    let symptom_tags: [String]
    let status: String
    let assigned_staff_id: String?
    let submitted_at: String
    let tending_until: String?
    let eta: Double?
    let fatigue_score_at_assignment: Double?

    var id: String { event_id }
}

/// GET /dashboard-state — one atomic snapshot of staff + events from a
/// single backend read. The app polls this instead of maintaining any
/// local copy of simulation state: the backend is the sole source of
/// truth, the app just continuously reflects it.
struct DashboardStateResponse: Codable, Equatable {
    let server_time: String
    let time_scale: Double
    let staff: [StaffPosition]
    let events: [EventItem]
}

struct ActiveEvent: Identifiable, Equatable {
    let id: String
    let room: String
    let symptomTags: [String]
    let submittedAt: String
    let tier: Int
    let assignedStaffId: String?
    let eta: Double?
    let fatigueScoreAtAssignment: Double?
    var status: String

    init(id: String, room: String, symptomTags: [String], submittedAt: String, tier: Int, assignedStaffId: String?, eta: Double?, fatigueScoreAtAssignment: Double?, status: String) {
        self.id = id
        self.room = room
        self.symptomTags = symptomTags
        self.submittedAt = submittedAt
        self.tier = tier
        self.assignedStaffId = assignedStaffId
        self.eta = eta
        self.fatigueScoreAtAssignment = fatigueScoreAtAssignment
        self.status = status
    }

    init(from response: RouteEventResponse, room: String, symptomTags: [String], submittedAt: String) {
        self.init(
            id: response.event_id,
            room: room,
            symptomTags: symptomTags,
            submittedAt: submittedAt,
            tier: response.tier,
            assignedStaffId: response.assigned_staff_id,
            eta: response.eta,
            fatigueScoreAtAssignment: response.fatigue_score_at_assignment,
            status: response.status
        )
    }

    /// The path that matters going forward: every ActiveEvent the app
    /// displays after the initial submission is built from a polled
    /// EventItem — never hand-patched from a cached response.
    init(from item: EventItem) {
        self.init(
            id: item.event_id,
            room: item.room,
            symptomTags: item.symptom_tags,
            submittedAt: item.submitted_at,
            tier: item.tier,
            assignedStaffId: item.assigned_staff_id,
            eta: item.eta,
            fatigueScoreAtAssignment: item.fatigue_score_at_assignment,
            status: item.status
        )
    }
}

enum AppScreen: Equatable {
    case eventForm
    case decisionReveal
    case mainApp
}

extension Date {
    var iso8601String: String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.string(from: self)
    }
}

extension Color {
    static func tierColor(for tier: Int) -> Color {
        switch tier {
        case 1:
            return .red
        case 2:
            return .orange
        case 3:
            return .green
        default:
            return .gray
        }
    }
}
